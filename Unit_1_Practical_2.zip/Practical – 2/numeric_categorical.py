import pandas as pd

df = pd.read_csv("airline.csv")

print("Numeric Attributes:")
print(df.select_dtypes(include=["number"]).columns.tolist())

print("Categorical Attributes:")
print(df.select_dtypes(include=["object", "category"]).columns.tolist())
