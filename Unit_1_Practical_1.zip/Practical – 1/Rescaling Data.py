import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Read dataset
df = pd.read_csv("cleaned_auto_mpg.csv")

# Select numeric columns
numeric_data = df.select_dtypes(include=["number"])

# Apply Min-Max Scaling
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(numeric_data)

# Convert into DataFrame
scaled_df = pd.DataFrame(scaled_data, columns=numeric_data.columns)

# Display rescaled data
print("Rescaled Data:")
print(scaled_df.head())

# Save rescaled data
scaled_df.to_csv("rescaled_auto_mpg.csv", index=False)