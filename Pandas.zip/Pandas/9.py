import pandas as pd

# German cars data
GermanCars = {
    'Company': ['Ford', 'Mercedes', 'BMV', 'Audi'],
    'Price': [23845, 171995, 135925, 71400]
}

# Japanese cars data
japaneseCars = {
    'Company': ['Toyota', 'Honda', 'Nissan', 'Mitsubishi'],
    'Price': [29995, 23600, 61500, 58900]
}

# Create DataFrames
df1 = pd.DataFrame(GermanCars)
df2 = pd.DataFrame(japaneseCars)

# Concatenate two DataFrames
result = pd.concat([df1, df2], ignore_index=True)

# Display result
print("Concatenated DataFrame:")
print(result)