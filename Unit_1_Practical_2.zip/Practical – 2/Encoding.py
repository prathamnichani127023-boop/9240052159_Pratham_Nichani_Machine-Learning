import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Read dataset
df = pd.read_csv("cleaned_airline.csv")

# Select categorical columns
categorical_columns = df.select_dtypes(include=["object", "category"]).columns

# Apply Label Encoding
encoder = LabelEncoder()

for column in categorical_columns:
    df[column] = encoder.fit_transform(df[column].astype(str))

# Display encoded data
print("Encoded Data:")
print(df.head())

# Save encoded data
df.to_csv("encoded_airline.csv", index=False)