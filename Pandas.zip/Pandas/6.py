import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Convert price to numeric
df["price"] = pd.to_numeric(df["price"], errors="coerce")

# Find highest price car of each company
highest_price = df.loc[df.groupby("company")["price"].idxmax()]

print("Each Company's Highest Price Car:")
print(highest_price)