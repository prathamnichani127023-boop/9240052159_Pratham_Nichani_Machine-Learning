import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Read dataset
df = pd.read_csv("cleaned_auto_mpg.csv")

# Select numeric attributes
data = df.select_dtypes(include=["number"])

# Handle missing values
data = data.dropna()

# Standardize the data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(data)

# Apply PCA
pca = PCA(n_components=2)
pca_data = pca.fit_transform(scaled_data)

# Display reduced data
result = pd.DataFrame(pca_data,columns=["PC1", "PC2"])

print("Data after PCA:")
print(result.head())

# Display explained variance
print("\nExplained Variance Ratio:")
print(pca.explained_variance_ratio_)

# Save result
result.to_csv("pca_auto_mpg.csv", index=False)
print("\nPCA result saved successfully.")
