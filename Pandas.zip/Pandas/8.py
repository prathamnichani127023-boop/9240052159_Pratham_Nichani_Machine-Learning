import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Convert price column to numeric
df["price"] = pd.to_numeric(df["price"], errors="coerce")

# Sort all cars by price in ascending order
sorted_cars = df.sort_values(by="price")

print("All Cars Sorted by Price:")
print(sorted_cars)