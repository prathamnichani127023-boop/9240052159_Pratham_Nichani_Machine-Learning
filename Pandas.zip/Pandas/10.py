import pandas as pd

# Create first dictionary
Car_Price = {
    'Company': ['Toyota', 'Honda', 'BMV', 'Audi'],
    'Price': [23845, 17995, 135925, 71400]
}

# Create second dictionary
car_Horsepower = {
    'Company': ['Toyota', 'Honda', 'BMV', 'Audi'],
    'horsepower': [141, 80, 182, 160]
}

# Create DataFrames
df1 = pd.DataFrame(Car_Price)
df2 = pd.DataFrame(car_Horsepower)

# Merge two DataFrames
merged_df = pd.merge(df1, df2, on='Company')

# Display result
print("Merged DataFrame:")
print(merged_df)
