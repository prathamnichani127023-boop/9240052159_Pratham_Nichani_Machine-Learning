import pandas as pd
import numpy as np

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Replace ?, n.a, and NaN values with NaN
df.replace(["?", "n.a", "NaN", ""], np.nan, inplace=True)

# Save the cleaned dataset to the CSV file
df.to_csv("Automobile_data.csv", index=False)

print("Dataset cleaned and CSV file updated successfully!")
print(df.head())