import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Print first five rows
print("First Five Rows:")
print(df.head())

# Print last five rows
print("\nLast Five Rows:")
print(df.tail())
