import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Print all Toyota cars
toyota_cars = df[df["company"].str.lower() == "toyota"]

print("All Toyota Cars Details:")
print(toyota_cars)