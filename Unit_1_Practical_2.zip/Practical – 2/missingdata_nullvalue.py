import pandas as pd
import numpy as np

# Read dataset
df = pd.read_csv("airline.csv")

# Replace missing values with NaN
df.replace(["?", "n.a", "NaN", ""], np.nan, inplace=True)

# Display missing values
print("Missing Values:")
print(df.isnull().sum())

# Remove rows containing null values
df.dropna(inplace=True)

# Display cleaned dataset
print("\nCleaned Dataset:")
print(df.head())

# Save cleaned dataset
df.to_csv("cleaned_airline.csv", index=False)