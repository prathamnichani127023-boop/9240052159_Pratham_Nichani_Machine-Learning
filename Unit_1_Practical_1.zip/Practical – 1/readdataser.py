# Read Dataset - Csv,text,json,xlsx
import pandas as pd

df = pd.read_csv('auto-mpg.csv')
print(df.head())






