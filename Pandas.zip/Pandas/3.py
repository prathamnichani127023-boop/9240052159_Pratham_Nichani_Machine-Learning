import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Convert price column to numeric
df["price"] = pd.to_numeric(df["price"], errors="coerce")

# Find the most expensive car
expensive_car = df.loc[df["price"].idxmax()]

# Print company name and price
print("Most Expensive Car Company:", expensive_car["company"])
print("Price:", expensive_car["price"])