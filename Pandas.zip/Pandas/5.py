import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Count total cars per company
car_count = df["company"].value_counts()

print("Total Cars per Company:")
print(car_count)