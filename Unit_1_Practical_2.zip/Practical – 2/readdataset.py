# Read Dataset - Csv,text,json,xlsx
import pandas as pd

df = pd.read_csv('Airline.csv')
print(df.head())

