import pandas as pd

# Read the dataset
df = pd.read_csv("Dataset_pandas_exercise.csv")

# Convert mileage to numeric
df["average-mileage"] = pd.to_numeric(
    df["average-mileage"], errors="coerce"
)

# Calculate average mileage of each company
avg_mileage = df.groupby("company")["average-mileage"].mean()

print("Average Mileage of Each Company:")
print(avg_mileage)
